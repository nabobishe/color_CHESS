import os
import sys
import pygame

from data.consts import P1, P2, P1dark, P2dark


# Завершает программу
def terminate():
    pygame.quit()
    sys.exit()


# Загружает спрайт
def load_image(name, colorkey=None, piece=False):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    if piece:
        pixels = pygame.PixelArray(image)
        pixels.replace(to_RGB("#63c74d"), to_RGB(P1))
        pixels.replace(to_RGB("#3e8948"), to_RGB(P1dark))
        pixels.replace(to_RGB("#167322"), to_RGB(P2))
        pixels.replace(to_RGB("#0e4715"), to_RGB(P2dark))
    return image


# Проверяет корректность координат
def correct_coords(row, col):
    return 0 <= row < 8 and 0 <= col < 8


# Проверяет, есть ли в клетке фигура
def figure(board, x, y):
    return board.board[x][y][0] is not None


# Проверяет, есть ли в клетке королева
def IsQueen(board, x, y):
    return "<class 'data.pieces.Queen'>" == str(type(board.board[x][y][0]))

def wot_fig(board, x, y):
    if not figure(board, x, y):
        return False
    if board.board[x][y][0].color == P1:
        col = "p1_"
    else:
        col = "p2_"
    if "<class 'data.pieces.Queen'>" == str(type(board.board[x][y][0])):
        return col + "queen"
    elif "<class 'data.pieces.Rook'>" == str(type(board.board[x][y][0])):
        return col + "rook"
    elif "<class 'data.pieces.Bishop'>" == str(type(board.board[x][y][0])):
        return col + "bishop"
    else:
        return col + "knight"
# Возвращает цвет фигуры
def color(board, x, y):
    return board.board[x][y][0].color


# Возвращает знак числа
def sign(a):
    if a > 0:
        return 1
    elif a < 0:
        return -1
    return 0


# Подсчет краски на клетках
def ink_count(board):
    a, b = 0, 0
    for i in range(8):
        for j in range(8):
            if board[j][i][1] == P1:
                a += 1
            elif board[j][i][1] == P2:
                b += 1
    return (a, b)

def to_RGB(col):
    d = {
        "1": 1,
        "2": 2,
        "3": 3,
        "4": 4,
        "5": 5,
        "6": 6,
        "7": 7,
        "8": 8,
        "9": 9,
        "a": 10,
        "b": 11,
        "c": 12,
        "d": 13,
        "e": 14,
        "f": 15,
        "0": 0
    }
    r = d[col[1]] * 16 + d[col[2]]
    g = d[col[3]] * 16 + d[col[4]]
    b = d[col[5]] * 16 + d[col[6]]
    return r, g, b