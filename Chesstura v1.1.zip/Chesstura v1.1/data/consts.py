SIZE = WIDTH, HEIGHT = (800, 600)
TILE_SIZE = 50
BLACK = "#000000"  # теперь константы BLACK и WHITE не отвечают за цвета фигур
WHITE = "#ffffff"
GREY = "#808080"
RED = "#ff0000"
GREEN = "#00990A"
BG = "#0c1526"
FPS = 60
NEED_TO_WIN = 0.60
RESPAWN = 7

with open("data/settings.txt", "r", encoding='utf-8') as fin:
    a = fin.readlines()
    P1 = a[0].split(" = ")[1].strip()
    P1dark = a[1].split(" = ")[1].strip()
    P2 = a[2].split(" = ")[1].strip()
    P2dark = a[3].split(" = ")[1].strip()

SPRITES = {
    'b_pawn': 'sprites/b_pawn.png',
    'b_rook': 'sprites/b_rook.png',
    'b_knight': 'sprites/b_knight.png',
    'b_bishop': 'sprites/b_bishop.png',
    'b_queen': 'sprites/b_queen.png',
    'b_king': 'sprites/b_king.png',
    'w_pawn': 'sprites/w_pawn.png',
    'w_rook': 'sprites/w_rook.png',
    'w_knight': 'sprites/w_knight.png',
    'w_bishop': 'sprites/w_bishop.png',
    'w_queen': 'sprites/w_queen.png',
    'w_king': 'sprites/w_king.png',
    'logo': 'sprites/logo.png'
}

COLS = {
    P1: "w",
    P2: "b"
}