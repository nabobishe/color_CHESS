import pygame

from data.consts import *
from data.functions import figure, color, correct_coords, ink_count, to_RGB


class Board:  # Шахматная доска
    def __init__(self, width, height, win=NEED_TO_WIN):
        self.width = width
        self.height = height
        # Для каждой клетки храним кортеж(!!!) с фигурой в клетке (или None) и цвет текущей клетки
        self.board = [[(None, GREY)] * width for i in range(height)]

        self.left = 10  # Левый верхний угол доски
        self.top = 10
        self.cell_size = 10

        # Если moving = False, фигура не выбрана, иначе в moving_piece хранится фигура, которой мы будем ходить
        self.moving = False
        self.moving_piece = (-1, -1)
        # Чей сейчас ход
        self.turn = P1
        self.gameover = False
        self.win_col = 0
        self.win = win # Какой процент нужен для победы (больше в режимее)

    def set_view(self, left, top, sz):
        self.left = left
        self.top = top
        self.cell_size = sz

    def render(self, screen):  # Рисуем доску
        x = self.left
        y = self.top
        pygame.draw.rect(screen, self.turn, (x - 10, y - 10, TILE_SIZE * 8 + 20, TILE_SIZE * 8 + 20), width=10)
        for i in range(self.height):
            for j in range(self.width):
                pygame.draw.rect(screen, self.board[j][i][1], (x, y, self.cell_size, self.cell_size), width=0)
                if (j, i) == self.moving_piece:  # Для удобства отметим фигуру, которую выбрали
                    pygame.draw.rect(screen, RED, (x, y, self.cell_size, self.cell_size), width=1)
                else:
                    pygame.draw.rect(screen, WHITE, (x, y, self.cell_size, self.cell_size), width=1)
                x += self.cell_size
            x = self.left
            y += self.cell_size

    def get_click(self, mouse_pos):  # Обработка клика
        cell = self.get_cell(mouse_pos)
        if not self.gameover:
            self.on_click(cell)

    def get_cell(self, mouse_pos):  # Возращает, в какую клетку мы тыкнулись
        board_x = self.left + self.cell_size * self.width
        board_y = self.top + self.cell_size * self.height
        if mouse_pos[0] < self.left or mouse_pos[0] > board_x or mouse_pos[1] < self.top or mouse_pos[1] > board_y:
            return
        x = (mouse_pos[0] - self.left) // self.cell_size
        y = (mouse_pos[1] - self.top) // self.cell_size
        return x, y

    def on_click(self, cell):  # Функция, выполняемая при нажатии
        if cell:
            x = cell[0]
            y = cell[1]
            try:
                # Выбираем, какой фигурой ходить
                if figure(self, x, y) and color(self, x, y) == self.turn:
                    if self.moving:
                        xtmp, ytmp = self.moving_piece  # Если переключили фигуру, отключаем анимацию у прошлой фигуры
                        self.board[xtmp][ytmp][0].anim = False
                    self.moving = True
                    self.moving_piece = (x, y)
                    self.board[x][y][0].anim = True
                elif self.moving:  # Ходим выбранной фигурой
                    x0, y0 = self.moving_piece
                    moved = self.board[x0][y0][0].move(x, y, self)
                    if moved:
                        if figure(self, x, y):
                            self.board[x][y][0].eliminate(self)
                        cur = self.board[x0][y0][0]
                        self.board[x0][y0] = (None, self.board[x0][y0][1])
                        self.board[x][y] = (cur, cur.color)
                        self.moving = False
                        self.board[x][y][0].anim = False
                        self.moving_piece = (-1, -1)
                        p1, p2 = ink_count(self.board)  # После каждого хода считаем краску на поле
                        #print(f"Player1: {p1}")
                        #print(f"Player2: {p2}")
                        if p1 >= 64 * self.win:
                            #print("Победил 1 игрок")  # Конец игры победа 1 игрока
                            self.gameover = True
                            self.win_col = P1
                        elif p2 >= 64 * self.win:
                            #print("Победил 2 игрок")  # Конец игры победа 2 игрока
                            self.gameover = True
                            self.win_col = P2
                        if self.turn == P1:
                            self.turn = P2
                        else:
                            self.turn = P1
            except IndexError:  # Чтобы не вылетало при нажатии на край доски, нужно сделать except
                pass


class Piece(pygame.sprite.Sprite):  # Класс, от которого наследуются все фигуры
    def __init__(self, x, y, color, spr, board, *args):
        super().__init__(*args)
        self.frames = []

        self.cut_sheet(spr, 6, 1)
        self.x = x
        self.y = y
        self.color = color
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.anim = False  # Нужно ли анимировать фигуру в данный момент?
        self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)

    def cut_sheet(self, sheet, columns, rows):  # Нарезка листа на спрайты
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns,
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self):  # обновление кадра
        if self.anim:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        else:
            self.cur_frame = 0
        self.image = self.frames[self.cur_frame]

    def eliminate(self, board):  # удаление спрайта после смерти
        self.kill()

    def base_ink(self, board, x, y, col=None):  # базовая функция для раскраски клетки
        if col == None:
            col = self.color
        if correct_coords(x, y):
            board.board[x][y] = (board.board[x][y][0], col)


class Scorebar:
    def __init__(self):
        self.width = 32
        self.top = 10
        self.left = 10
        self.cell_width = 20
        self.cell_height = 20
        self.p1 = 16
        self.p2 = 16
        self.font = pygame.font.Font("data/ui.otf", 25)

    def set_view(self, left, top, sz):
        self.left = left
        self.top = top
        self.cell_size = sz

    def render(self, screen):
        x = self.left
        y = self.top
        sum = self.p1 + self.p2
        wid1 = round(self.p1 * self.width * self.cell_width / sum)
        wid2 = self.width * self.cell_width - wid1
        pygame.draw.rect(screen, P1, (x, y, wid1, self.cell_height), width=0)
        pygame.draw.rect(screen, P2, (x + wid1, y, wid2, self.cell_height), width=0)
        text1 = self.font.render(f"{round(self.p1 / 64 * 100)}%", True, P1)
        text2 = self.font.render(f"{round(self.p2 / 64 * 100)}%", True, P2)
        screen.blit(text1, (x - 60, y - 15))
        screen.blit(text2, (x + self.width * self.cell_width + 5, y - 15))


class Statbar:  # Временая версия для примера, будет заменена на картину с той же информацией
    def __init__(self):
        self.width = 32
        self.top = 10
        self.left = 10
        self.font = pygame.font.Font("data/ui.otf", 25)

    def set_view(self, left, top, sz):
        self.left = left
        self.top = top
        self.cell_size = sz

    def render(self, screen, board):
        x = self.left
        y = self.top
        pygame.draw.rect(screen, RED, (x + 180, y + 5, 325, 35), width=2)
        text = self.font.render(f"ходит игрок {board.turn}%", True, WHITE)
        screen.blit(text, (x + 180, y))


class UiImage(pygame.sprite.Sprite):
    def __init__(self, x, y, spr, *args):
        super().__init__(*args)
        self.image = spr
        self.rect = self.image.get_rect().move(x, y)
