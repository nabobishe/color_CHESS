import pygame

from data.consts import *
from data.classes import Piece
from data.functions import load_image, correct_coords, figure, color, sign, IsQueen


# Класс пешки
class Pawn(Piece):
    def __init__(self, x, y, col, board, *args):
        super().__init__(x, y, col, load_image(SPRITES[f"{COLS[col]}_pawn"], piece=True), board, *args)
        self.first = True  # True, если пешка ещё не ходила

    def move(self, x, y, board):  # передвигаем пешку
        if self.color == P1:  # направление пешки
            dir = 1
        else:
            dir = -1
        # пешка ест
        if figure(board, x, y) and color(board, x, y) != self.color and abs(x - self.x) == 1 and self.y - y == dir:
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            dx, dy = x - self.x, self.y - y
            self.x = x
            self.y = y
            self.ink(board, False, dx, dy)
            return True
        # пешка просто ходит
        elif not figure(board, x, y) and x == self.x and ((self.y - y == 2 * dir and self.first) or self.y - y == dir):
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            f = self.first and self.y - y == 2 * dir  # проверка случая, если в первый ход идем на 2 клетки
            dx, dy = 0, dir
            self.y = y
            self.ink(board, f, dx, dy)
            self.first = False
            return True
        else:
            return False

    def ink(self, board, first, dx, dy):  # красим клетки
        self.base_ink(board, self.x, self.y)
        self.base_ink(board, self.x + dx, self.y - dy)
        if first:
            self.base_ink(board, self.x, self.y + dy)


class Knight(Piece):
    def __init__(self, x, y, col, board, *args):
        super().__init__(x, y, col, load_image(SPRITES[f"{COLS[col]}_knight"], piece=True), board, *args)

    def move(self, x, y, board):
        if figure(board, x, y) and (abs(self.x - x) * abs(self.y - y) == 2) and color(board, x, y) != self.color:
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            self.x = x
            self.y = y
            self.ink(board, 0, 0)
            if x > -1:  # Проверка возможности покраски клеток
                self.ink(board, - 1, 0)
            if y > -1:
                self.ink(board, 0, -1)
            if y < 8:
                self.ink(board, 0, 1)
            if x < 8:
                self.ink(board, 1, 0)
            return True
        elif not figure(board, x, y) and (abs(self.x - x) * abs(self.y - y) == 2):
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            self.x = x
            self.y = y
            self.ink(board, 0, 0)
            return True
        else:
            return False

    def ink(self, board, x, y):
        self.base_ink(board, self.x + x, self.y - y)


class Rook(Piece):
    def __init__(self, x, y, col, board, *args):
        super().__init__(x, y, col, load_image(SPRITES[f"{COLS[col]}_rook"], piece=True), board, *args)

    def move(self, x, y, board):
        col = True
        fig = True
        if x == self.x:
            diry = sign(y - self.y)
            dirx = 0
            way = abs(self.y - y)
        elif y == self.y:
            dirx = sign(x - self.x)
            diry = 0
            way = abs(self.x - x)
        else:
            return False  # не возможно сходить тк некоректные корды
        for i in range(1, way):  # Проверка на наличие фигур и клеток другого цвета на пути
            if figure(board, self.x + dirx * i, self.y + diry * i):
                fig = False
            if board.board[self.x + dirx * i][self.y + diry * i][1] == self.color or \
                    board.board[self.x + dirx * i][self.y + diry * i][1] == GREY:
                pass
            else:
                col = False
        if figure(board, x, y) and fig and color(board, x, y) != self.color and (col or IsQueen(board, x, y)):  # Проверка на цвет и фигуры по траектории, необходимо добавить исключние для ферзя
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            for i in range(1, way):
                self.ink(board, i * dirx, i * diry)
            self.x = x
            self.y = y
            return True
        elif not figure(board, x, y) and fig:
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            for i in range(1, way):
                self.ink(board, i * dirx, i * diry)
            self.x = x
            self.y = y
            return True
        else:
            return False

    def ink(self, board, x, y):
        self.base_ink(board, self.x, self.y)
        self.base_ink(board, self.x + x, self.y + y)


class Bishop(Piece):
    def __init__(self, x, y, col, board, *args):
        super().__init__(x, y, col, load_image(SPRITES[f"{COLS[col]}_bishop"], piece=True), board, *args)

    def move(self, x, y, board):
        col = True
        fig = True
        if abs(x - self.x) != abs(y - self.y):  # не возможно сходить тк некоректные корды
            return False
        dirx = sign(x - self.x)
        diry = sign(y - self.y)
        way = abs(self.y - y)
        if way == 0:
            return False  # не возможно сходить тк нажатие на клетку где и так стоит слон
        for i in range(1, way):  # Проверка на наличие фигур и клеток другого цвета на пути
            if figure(board, self.x + dirx * i, self.y + diry * i):
                fig = False
            if board.board[self.x + dirx * i][self.y + diry * i][1] == self.color or \
                    board.board[self.x + dirx * i][self.y + diry * i][1] == GREY:
                pass
            else:
                col = False
        if figure(board, x, y) and fig and color(board, x, y) != self.color and (col or IsQueen(board, x, y)):
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            for i in range(1, way):
                self.ink(board, i * dirx, i * diry)
            self.x = x
            self.y = y
            return True
        elif not figure(board, x, y) and fig:
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            for i in range(1, way):
                self.ink(board, i * dirx, i * diry)
            self.x = x
            self.y = y
            return True
        else:
            return False

    def ink(self, board, x, y):
        self.base_ink(board, self.x, self.y)
        self.base_ink(board, self.x + x, self.y + y)


class King(Piece):
    def __init__(self, x, y, col, board, *args):
        super().__init__(x, y, col, load_image(SPRITES[f"{COLS[col]}_king"], piece=True), board, *args)

    def move(self, x, y, board):
        if x == self.x and y == self.y:
            return False  # не возможно сходить тк нажатие на клетку где и так стоит король
        if abs(x - self.x) <= 1 and abs(y - self.y) <= 1:
            dirx = x - self.x
            diry = y - self.y
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            self.base_ink(board, x, y)
            self.x = x
            self.y = y
            diag = dirx != 0 and diry != 0 # True, если король идет по диагонали
            self.ink(board, dirx, diry, diag, False)
            return True
        else:
            return False  # не возможно сходить тк некоректные корды

    def ink(self, board, x, y, diag, dead):
        self.base_ink(board, self.x, self.y)
        self.base_ink(board, self.x + x, self.y + y)
        if dead:
            if self.color == P1:
                self.base_ink(board, x, y, P2) # Закраска всего поля противоположным цветом при смерте короля
            else:
                self.base_ink(board, x, y, P1)
        elif diag:
            self.base_ink(board, self.x + x, self.y)
            self.base_ink(board, self.x, self.y + y)
        else:
            self.base_ink(board, self.x + y, self.y + y)
            self.base_ink(board, self.x - y, self.y + y)
            self.base_ink(board, self.x + x, self.y + x)
            self.base_ink(board, self.x + x, self.y - x)

    def eliminate(self, board):
        for i in range(8):
            for j in range(8):
                self.ink(board, i, j, False, True) # Мгновенное поражение при потере короля
        self.kill()

class Queen(Piece):
    def __init__(self, x, y, col, board, *args):
        super().__init__(x, y, col, load_image(SPRITES[f"{COLS[col]}_queen"], piece=True), board, *args)

    def move(self, x, y, board):
        col = True
        fig = True
        way = 0
        if abs(x - self.x) != abs(y - self.y) and (self.y != y and self.x != x):# не возможно сходить тк некоректные корды
            return False
        way = max(abs(self.x - x), abs(self.y - y))
        dirx = sign(x - self.x)
        diry = sign(y - self.y)
        if way == 0:
            return False  # невозможно сходить тк нажатие на клетку где и так стоит королева
        for i in range(1, way):  # Проверка на наличие фигур и клеток другого цвета на пути
            if figure(board, self.x + dirx * i, self.y + diry * i):
                fig = False
            if board.board[self.x + dirx * i][self.y + diry * i][1] == self.color or board.board[self.x + dirx * i][self.y + diry * i][1] == GREY:
                pass
            else:
                col = False
        if figure(board, x, y) and fig and col and color(board, x, y) != self.color:
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            for i in range(1, way):
                self.ink(board, i * dirx, i * diry)
            self.x = x
            self.y = y
            return True
        elif not figure(board, x, y) and fig:
            self.rect = self.image.get_rect().move(board.left + TILE_SIZE * x, board.top + TILE_SIZE * y)
            for i in range(1, way):
                self.ink(board, i * dirx, i * diry)
            self.x = x
            self.y = y
            return True
        else:
            return False

    def ink(self, board, x, y):
        self.base_ink(board, self.x, self.y)
        self.base_ink(board, self.x + x, self.y + y)
