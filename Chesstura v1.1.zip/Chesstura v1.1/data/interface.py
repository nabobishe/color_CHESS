import pygame

from data.consts import FPS, WHITE, BG, WIDTH, HEIGHT
from data.consts import P1, P2, P1dark, P2dark
from data.functions import load_image, terminate

# Цвет кнопок
GREEN = (0, 150, 10)
dGREEN = (0, 100, 10)

# Цвета для фигур
P1_1G = "#63c74d"
P1_2G = "#3e8948"
P2_1G = "#167322"
P2_2G = "#0e4715"

P1_1O = "#ff7200"
P1_2O = "#a84d03"
P2_1O = "#e63219"
P2_2O = "#97230d"

P1_1B = "#1bbeab"
P1_2B = "#12796d"
P2_1B = "#0d0ddc"
P2_2B = "#080880"

P1_1P = "#c12d74"
P1_2P = "#8a184f"
P2_1P = "#6e04b6"
P2_2P = "#450471"

# Цвета фигур для записи в файл
p1 = P1
p1d = P1dark
p2 = P2
p2d = P2dark


class Text:
    def __init__(self, text, x, y, font):
        self.text = text
        self.x = x
        self.y = y
        self.font = font

    def draw(self, screen):
        string_rendered = self.font.render(self.text, 1, WHITE)
        line = string_rendered.get_rect()
        screen.blit(string_rendered, (self.x, self.y))


class Button:
    def __init__(self, x, y, width, height, text, c=GREEN, dc=dGREEN, p=-1):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text.split("\n")
        self.col = c
        self.c = c
        self.dc = dc
        self.p = p

    def render(self, screen):
        font = pygame.font.Font("data/ui.otf", 30)
        pygame.draw.rect(screen, self.col, (self.x, self.y, self.width, self.height), width=0)
        string_rendered = font.render("E", 1, WHITE)
        line = string_rendered.get_rect()
        y = self.y + self.height // 3 - ((line.height // 2) * len(self.text)) // 2
        for t in self.text:
            string_rendered = font.render(t, 1, WHITE)
            line = string_rendered.get_rect()
            screen.blit(string_rendered,
                        (self.x + self.width // 2 - line.width // 2, y))
            y += line.height // 2

    def get_click(self, mouse_pos, screen):  # Обработка клика
        if self.check_mouse(mouse_pos):
            return "\n".join(self.text)
        return "None"

    def on_mouse(self, mouse_pos):
        if self.check_mouse(mouse_pos):
            self.col = self.dc
        else:
            self.col = self.c

    def check_mouse(self, mouse_pos):
        x, y = mouse_pos
        if self.x <= x <= self.x + self.width and self.y <= y <= self.y + self.height:
            return True
        return False

    def reink(self):
        global p1, p1d, p2, p2d
        with open("data/settings.txt", "w", encoding='utf-8') as fout:
            if self.p == 1:
                fout.write(f"P1 = {self.c}\nP1dark = {self.dc}\nP2 = {p2}\nP2dark = {p2d}")
                p1 = self.c
                p1d = self.dc
            else:
                fout.write(f"P1 = {p1}\nP1dark = {p1d}\nP2 = {self.c}\nP2dark = {self.dc}")
                p2 = self.c
                p2d = self.dc


def nothing(screen):
    pass


def start_screen(screen):
    intro_text = ["PAINT OR MATE",
                  "CHESSPLAT",
                  "HOW TO PLAY",
                  "OPTIONS",
                  "ABOUT GAME"
                  ]
    funcs = {
        "PAINT OR MATE": launch,
        "CHESSPLAT": launch_splat,
        "OPTIONS": settings,
        "ABOUT GAME": credits,
        "HOW TO PLAY": manual,
        "None": nothing
    }
    buttons = []
    screen.fill(BG)

    # Делаем кнопки
    text_height = 270
    for line in intro_text:
        buttons.append(Button(225, text_height, 300, 50, line))
        text_height += 60

    while True:
        if start:
            return True
        if splat:
            return False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEMOTION:
                for b in buttons:
                    b.on_mouse(event.pos)
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                for b in buttons:
                    s = b.get_click(event.pos, screen)
                    funcs[s](screen)
        screen.fill(BG)

        # Логотип
        logo = pygame.transform.scale(load_image('sprites/biglogo.png'), (500, 224))
        screen.blit(logo, (150, 20))
        font = pygame.font.Font("data/ui.otf", 16)

        # Пояснение к логотипу
        string_rendered = font.render("Яркий взгляд на шахматы", 1, WHITE)
        line = string_rendered.get_rect()
        screen.blit(string_rendered, (400, 160))

        for b in buttons:
            b.render(screen)
        pygame.display.flip()


def end_screen(screen, col):
    buttons = []
    screen.fill(col)

    # Делаем кнопку
    btn = Button(225, 370, 300, 50, "Закрыть")

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEMOTION:
                btn.on_mouse(event.pos)
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                terminate()
        screen.fill(col)

        font = pygame.font.Font("data/ui.otf", 32)
        string_rendered = font.render("Победил!", 1, WHITE)
        line = string_rendered.get_rect()
        screen.blit(string_rendered, (300, 160))

        btn.render(screen)
        pygame.display.flip()


def launch(screen):
    global start
    start = True


def launch_splat(screen):
    global splat
    splat = True


def settings(screen):
    font = pygame.font.Font("data/ui.otf", 30)
    bigfont = pygame.font.Font("data/ui.otf", 50)
    smallfont = pygame.font.Font("data/ui.otf", 16)
    text = [Text("Настройки", 250, 10, bigfont),
            Text("Цвет фигур", 300, 100, font),
            Text("Игрок 1:", 100, 175, font),
            Text("Игрок 2:", 100, 225, font),
            Text("Чтобы применить новые настройки, перезапустите приложение", 100, 350, smallfont),
            # Text("Игровой режим:", 250, 300, font)
            ]
    buttons = [Button(10, 10, 50, 50, "X"),
               Button(250, 195, 30, 30, " ", P1_1O, P1_2O, 1),
               Button(250, 245, 30, 30, " ", P2_1O, P2_2O, 2),
               Button(285, 195, 30, 30, " ", P1_1B, P1_2B, 1),
               Button(285, 245, 30, 30, " ", P2_1B, P2_2B, 2),
               Button(320, 195, 30, 30, " ", P1_1G, P1_2G, 1),
               Button(320, 245, 30, 30, " ", P2_1G, P2_2G, 2),
               Button(355, 195, 30, 30, " ", P1_1P, P1_2P, 1),
               Button(355, 245, 30, 30, " ", P2_1P, P2_2P, 2),
               ]

    # Button(80, 370, 200, 120, "Шахматы"),
    # Button(300, 370, 200, 120, "Бои за поля"),
    # Button(520, 370, 200, 120, "Paint\nor\nMate")

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEMOTION:
                for b in buttons:
                    b.on_mouse(event.pos)
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                for b in buttons:
                    s = b.get_click(event.pos, screen)
                    if s == "X":
                        return
                    elif s == " ":
                        b.reink()
        screen.fill(BG)
        for line in text:
            line.draw(screen)
        for b in buttons:
            b.render(screen)
        pygame.display.flip()


def credits(screen):
    font = pygame.font.Font("data/ui.otf", 30)
    bigfont = pygame.font.Font("data/ui.otf", 50)
    text = [Text("Об игре", 250, 10, bigfont),
            Text("Над игрой работали", 200, 100, font),
            Text("Код: Плехов Игнат, Кильметов Данил", 50, 175, font),
            Text("Графика: Кильметов Данил, Фокин Алексей", 50, 225, font),
            ]
    buttons = [Button(10, 10, 50, 50, "X")
               ]

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEMOTION:
                for b in buttons:
                    b.on_mouse(event.pos)
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                for b in buttons:
                    s = b.get_click(event.pos, screen)
                    if s == "X":
                        return
        screen.fill(BG)
        for line in text:
            line.draw(screen)
        for b in buttons:
            b.render(screen)
        pygame.display.flip()


def manual(screen):
    buttons = [Button(10, 10, 50, 50, "X")]
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEMOTION:
                for b in buttons:
                    b.on_mouse(event.pos)
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                for b in buttons:
                    s = b.get_click(event.pos, screen)
                    if s == "X":
                        return
        screen.fill(BG)
        logo = pygame.transform.scale(load_image('sprites/manual.png'), (WIDTH, HEIGHT))
        screen.blit(logo, (0, 0))
        for b in buttons:
            b.render(screen)
        pygame.display.flip()


start = False
splat = False
